extends Node
# Autoload "Sound": musik per level + efek suara.

const TRACKS := {
	"royal": "res://assets/audio/music_royal.ogg",
	"savanna": "res://assets/audio/music_savanna.ogg",
	"luina": "res://assets/audio/music_luina.ogg",
	"lulunar": "res://assets/audio/music_lulunar.ogg",
}
const SFX_NAMES := ["click", "tick", "pop", "slash", "boom", "destroy", "special", "win", "lose", "coin", "star", "error", "swap", "hammer", "shuffle"]

var music: AudioStreamPlayer
var sfx_players: Array = []
var sfx_streams: Dictionary = {}
var current_track: String = ""
var unlocked: bool = false
var _next_sfx: int = 0


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	music = AudioStreamPlayer.new()
	music.volume_db = -6.0
	add_child(music)
	music.finished.connect(_on_music_finished)
	for i in 8:
		var p := AudioStreamPlayer.new()
		p.volume_db = -2.0
		add_child(p)
		sfx_players.append(p)
	for n in SFX_NAMES:
		var s = load("res://assets/audio/sfx_%s.wav" % n)
		if s != null:
			sfx_streams[n] = s


func _on_music_finished() -> void:
	if Game.music_on and music.stream != null:
		music.play()


# Level 1-20 royal | 21-40 savanna | 41-50 luina | 51-70 lulunar | 71+ acak
func track_for_level(level: int) -> String:
	if level <= 20:
		return "royal"
	if level <= 40:
		return "savanna"
	if level <= 50:
		return "luina"
	if level <= 70:
		return "lulunar"
	var keys: Array = TRACKS.keys()
	return str(keys[randi() % keys.size()])


func play_level_music(level: int) -> void:
	play_music(track_for_level(level))


func play_music(key: String) -> void:
	if not TRACKS.has(key):
		return
	if key == current_track and music.playing:
		return
	var s = load(TRACKS[key])
	if s == null:
		return
	if "loop" in s:
		s.loop = true
	current_track = key
	music.stream = s
	if Game.music_on:
		music.play()


func ensure_playing() -> void:
	if Game.music_on and music.stream != null and not music.playing:
		music.play()


func set_music(on: bool) -> void:
	Game.music_on = on
	if on:
		ensure_playing()
	else:
		music.stop()
	Game.save_game()


func set_sfx(on: bool) -> void:
	Game.sfx_on = on
	Game.save_game()


func sfx(sfx_name: String, pitch: float = 1.0) -> void:
	if not Game.sfx_on:
		return
	if not sfx_streams.has(sfx_name):
		return
	var p: AudioStreamPlayer = sfx_players[_next_sfx]
	_next_sfx = (_next_sfx + 1) % sfx_players.size()
	p.stream = sfx_streams[sfx_name]
	p.pitch_scale = pitch
	p.play()
