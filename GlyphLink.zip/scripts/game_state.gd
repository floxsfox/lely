extends Node
# Autoload "Game": data progres, koin, bintang, navigasi layar.

signal coins_changed

const SAVE_PATH := "user://glyphlink_save.json"
const MAX_LEVEL := 1000000

var main = null
var coins: int = 300
var highest: int = 1
var level_stars: Dictionary = {}
var level_score: Dictionary = {}
var music_on: bool = true
var sfx_on: bool = true
var last_daily: String = ""
var current_level: int = 1
var total_stars: int = 0


func _ready() -> void:
	load_game()


func go(screen_name: String) -> void:
	if main != null:
		main.show_screen(screen_name)


func stars_of(level: int) -> int:
	return int(level_stars.get(str(level), 0))


func best_score(level: int) -> int:
	return int(level_score.get(str(level), 0))


func complete_level(level: int, stars: int, score: int) -> void:
	var key := str(level)
	var old := int(level_stars.get(key, 0))
	if stars > old:
		total_stars += stars - old
		level_stars[key] = stars
	if score > int(level_score.get(key, 0)):
		level_score[key] = score
	if level >= highest:
		highest = mini(level + 1, MAX_LEVEL)
	save_game()


func add_coins(n: int) -> void:
	coins += n
	coins_changed.emit()
	save_game()


func spend_coins(n: int) -> bool:
	if coins < n:
		return false
	coins -= n
	coins_changed.emit()
	save_game()
	return true


func daily_available() -> bool:
	return last_daily != Time.get_date_string_from_system()


func claim_daily() -> int:
	last_daily = Time.get_date_string_from_system()
	add_coins(150)
	return 150


func reset_progress() -> void:
	coins = 300
	highest = 1
	level_stars = {}
	level_score = {}
	total_stars = 0
	current_level = 1
	coins_changed.emit()
	save_game()


func save_game() -> void:
	var data := {
		"coins": coins,
		"highest": highest,
		"stars": level_stars,
		"scores": level_score,
		"music": music_on,
		"sfx": sfx_on,
		"daily": last_daily,
	}
	var f = FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f != null:
		f.store_string(JSON.stringify(data))
		f.close()


func load_game() -> void:
	if not FileAccess.file_exists(SAVE_PATH):
		return
	var f = FileAccess.open(SAVE_PATH, FileAccess.READ)
	if f == null:
		return
	var txt: String = f.get_as_text()
	f.close()
	var data = JSON.parse_string(txt)
	if typeof(data) != TYPE_DICTIONARY:
		return
	coins = int(data.get("coins", 300))
	highest = clampi(int(data.get("highest", 1)), 1, MAX_LEVEL)
	level_stars = data.get("stars", {})
	level_score = data.get("scores", {})
	music_on = bool(data.get("music", true))
	sfx_on = bool(data.get("sfx", true))
	last_daily = str(data.get("daily", ""))
	total_stars = 0
	for k in level_stars.keys():
		total_stars += int(level_stars[k])
	current_level = highest
