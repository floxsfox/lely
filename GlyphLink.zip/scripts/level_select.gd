extends "res://scripts/screen_base.gd"
# Pilih level: halaman 25 level + lompat cepat (mendukung sampai 1.000.000).

const PER_PAGE := 25

var page_start: int = 1
var grid_root: Control
var page_label: Label


func build() -> void:
	bg.texture = UI.tex("bg_menu", "jpg")
	var back := UI.icon_button("ic_arrow_l", "btn_blue", Vector2(80, 80))
	back.position = Vector2(24, 24)
	back.pressed.connect(func(): Game.go("menu"))
	content.add_child(back)
	var title := UI.label("PILIH LEVEL", 46, Color.WHITE, 8)
	title.position = Vector2(110, 24)
	title.size = Vector2(380, 80)
	content.add_child(title)
	coin_pill(Vector2(500, 34), 200.0)

	page_label = UI.label("", 30, Color(1, 0.92, 0.55), 6)
	page_label.position = Vector2(24, 130)
	page_label.size = Vector2(672, 50)
	content.add_child(page_label)

	grid_root = Control.new()
	grid_root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(grid_root)

	var jumps := [-1000, -100, -25, 25, 100, 1000]
	for i in jumps.size():
		var jv: int = jumps[i]
		var txt := ("+%d" % jv) if jv > 0 else ("%d" % jv)
		var b := UI.button(txt, "btn_blue", Vector2(104, 76), 26)
		b.position = Vector2(23.0 + float(i) * 114.0, 916)
		b.pressed.connect(_jump.bind(jv))
		content.add_child(b)

	var cur := UI.button("KE LEVEL SAAT INI", "btn_green", Vector2(460, 92), 34)
	cur.position = Vector2(130, 1016)
	cur.pressed.connect(_goto_current)
	content.add_child(cur)
	var first := UI.button("KE LEVEL 1", "btn_orange", Vector2(280, 80), 30)
	first.position = Vector2(220, 1124)
	first.pressed.connect(_goto_first)
	content.add_child(first)

	page_start = _page_of(Game.highest)
	_rebuild()


func _page_of(lv: int) -> int:
	return floori(float(lv - 1) / float(PER_PAGE)) * PER_PAGE + 1


func _jump(delta: int) -> void:
	page_start += delta
	_rebuild()


func _goto_current() -> void:
	page_start = _page_of(Game.highest)
	_rebuild()


func _goto_first() -> void:
	page_start = 1
	_rebuild()


func _play(lv: int) -> void:
	Game.current_level = lv
	Game.go("game")


func _locked() -> void:
	Sound.sfx("error")


func _rebuild() -> void:
	for ch in grid_root.get_children():
		ch.queue_free()
	page_start = clampi(page_start, 1, _page_of(Game.MAX_LEVEL))
	page_start = _page_of(page_start)
	var end_level := mini(page_start + PER_PAGE - 1, Game.MAX_LEVEL)
	page_label.text = "Level %s - %s" % [UI.fmt(page_start), UI.fmt(end_level)]
	for i in PER_PAGE:
		var lv := page_start + i
		if lv > Game.MAX_LEVEL:
			break
		var cx := i % 5
		var cy := floori(float(i) / 5.0)
		var unlocked := lv <= Game.highest
		var stars := Game.stars_of(lv)
		var style := "btn_gray"
		if unlocked:
			if lv % 10 == 0:
				style = "btn_purple"
			elif stars > 0:
				style = "btn_green"
			else:
				style = "btn_orange"
		var b := UI.button("", style, Vector2(120, 120))
		b.position = Vector2(40.0 + float(cx) * 130.0, 200.0 + float(cy) * 140.0)
		grid_root.add_child(b)
		if unlocked:
			var nd := str(lv)
			var fs := 44
			match nd.length():
				4:
					fs = 36
				5:
					fs = 30
				6:
					fs = 26
				7:
					fs = 22
			var l := UI.label(nd, fs, Color.WHITE, 6)
			l.position = Vector2(0, 12)
			l.size = Vector2(120, 56)
			b.add_child(l)
			for s in 3:
				b.add_child(UI.tex_rect("star_on" if s < stars else "star_off", Vector2(12.0 + float(s) * 32.0, 66), Vector2(30, 30)))
			b.pressed.connect(_play.bind(lv))
		else:
			b.add_child(UI.tex_rect("ic_lock", Vector2(30, 14), Vector2(60, 60)))
			b.pressed.connect(_locked)
