extends "res://scripts/screen_base.gd"
# Menu utama: logo, tombol main, pilih level, pengaturan, hadiah harian.

var popup: Dictionary = {}
var gift_badge: Control
var music_btn: Button


func build() -> void:
	bg.texture = UI.tex("bg_menu", "jpg")
	_floating_gems()
	coin_pill(Vector2(500, 26), 200.0)

	var logo := UI.tex_rect("logo", Vector2(50, 110), Vector2(620, 358))
	content.add_child(logo)
	var lt := create_tween()
	lt.set_loops()
	lt.tween_property(logo, "position:y", 122.0, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	lt.tween_property(logo, "position:y", 106.0, 1.6).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	var play := UI.button("", "btn_green", Vector2(480, 150))
	play.position = Vector2(120, 520)
	content.add_child(play)
	var pl := UI.label("MAIN", 62, Color.WHITE, 10)
	pl.position = Vector2(0, 8)
	pl.size = Vector2(480, 86)
	play.add_child(pl)
	var pl2 := UI.label("Level %s" % UI.fmt(Game.highest), 28, Color(0.9, 1.0, 0.85), 6)
	pl2.position = Vector2(0, 88)
	pl2.size = Vector2(480, 36)
	play.add_child(pl2)
	play.pressed.connect(_on_play)
	var pt := create_tween()
	pt.set_loops()
	pt.tween_property(play, "scale", Vector2(1.04, 1.04), 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	pt.tween_property(play, "scale", Vector2.ONE, 0.8).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)

	var lv := UI.button("PILIH LEVEL", "btn_blue", Vector2(480, 104), 42)
	lv.position = Vector2(120, 710)
	content.add_child(lv)
	lv.pressed.connect(func(): Game.go("levels"))

	content.add_child(UI.panel(Vector2(110, 850), Vector2(500, 110), "panel_dark", 36))
	content.add_child(UI.tex_rect("star_on", Vector2(130, 860), Vector2(90, 90)))
	var s1 := UI.label("%s" % UI.fmt(Game.total_stars), 40, Color(1, 0.92, 0.5), 7, HORIZONTAL_ALIGNMENT_LEFT)
	s1.position = Vector2(226, 866)
	s1.size = Vector2(160, 78)
	content.add_child(s1)
	var s2 := UI.label("Terbuka\nLevel %s" % UI.fmt(Game.highest), 24, Color(0.85, 0.8, 1.0), 5)
	s2.position = Vector2(380, 860)
	s2.size = Vector2(220, 90)
	content.add_child(s2)

	var gear := UI.icon_button("ic_gear", "btn_purple", Vector2(100, 100))
	gear.position = Vector2(170, 1090)
	content.add_child(gear)
	gear.pressed.connect(_settings)

	var gift := UI.icon_button("ic_gift", "btn_orange", Vector2(100, 100))
	gift.position = Vector2(310, 1090)
	content.add_child(gift)
	gift.pressed.connect(_daily)
	gift_badge = UI.label("!", 26, Color.WHITE, 6)
	gift_badge.position = Vector2(74, -6)
	gift_badge.size = Vector2(34, 34)
	gift.add_child(gift_badge)
	gift_badge.visible = Game.daily_available()

	music_btn = UI.icon_button("ic_music_on" if Game.music_on else "ic_music_off", "btn_blue", Vector2(100, 100))
	music_btn.position = Vector2(450, 1090)
	content.add_child(music_btn)
	music_btn.pressed.connect(_toggle_music)

	var ft := UI.label("Level 1 - 1.000.000  |  Hubungkan simbol, raih bintang!", 20, Color(0.9, 0.85, 1.0), 4)
	ft.position = Vector2(0, 1214)
	ft.size = Vector2(720, 30)
	content.add_child(ft)

	Sound.play_level_music(Game.highest)
	if Game.daily_available() and not Game.has_meta("daily_prompted"):
		Game.set_meta("daily_prompted", true)
		_daily()


func _floating_gems() -> void:
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for i in 14:
		var sz := rng.randf_range(56.0, 116.0)
		var g := UI.tex_rect("sym_%d" % (i % 7), Vector2(rng.randf_range(-10.0, 650.0), rng.randf_range(0.0, 1200.0)), Vector2(sz, sz))
		g.modulate.a = rng.randf_range(0.28, 0.55)
		g.pivot_offset = Vector2(sz, sz) / 2.0
		g.rotation = rng.randf_range(-0.4, 0.4)
		content.add_child(g)
		var dy := rng.randf_range(20.0, 40.0)
		var dur := rng.randf_range(2.5, 4.5)
		var tw := g.create_tween()
		tw.set_loops()
		tw.tween_property(g, "position:y", g.position.y + dy, dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
		tw.tween_property(g, "position:y", g.position.y, dur).set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)


func _on_play() -> void:
	Game.current_level = Game.highest
	Game.go("game")


func _toggle_music() -> void:
	Sound.set_music(not Game.music_on)
	music_btn.get_child(0).texture = UI.tex("ic_music_on" if Game.music_on else "ic_music_off")


func _close_popup() -> void:
	if popup.has("root"):
		popup["root"].queue_free()
	popup = {}


func _dlabel(parent: Control, text: String, font_size: int, pos: Vector2, lsize: Vector2, color: Color = Color(0.22, 0.13, 0.45), align: HorizontalAlignment = HORIZONTAL_ALIGNMENT_CENTER) -> Label:
	var l := UI.label(text, font_size, color, 0, align)
	l.position = pos
	l.size = lsize
	parent.add_child(l)
	return l


func _btn(parent: Control, text: String, style: String, pos: Vector2, bsize: Vector2, cb: Callable, fs: int = 38) -> Button:
	var b := UI.button(text, style, bsize, fs)
	b.position = pos
	b.pressed.connect(cb)
	parent.add_child(b)
	return b


func _daily() -> void:
	if not popup.is_empty():
		return
	popup = UI.make_popup(self, Vector2(560, 560), "HADIAH HARIAN")
	var p: Panel = popup["panel"]
	p.add_child(UI.tex_rect("ic_gift", Vector2(180, 70), Vector2(200, 200)))
	if Game.daily_available():
		_dlabel(p, "Hadiah hari ini", 30, Vector2(20, 280), Vector2(520, 40))
		p.add_child(UI.tex_rect("coin", Vector2(170, 330), Vector2(70, 70)))
		var cl := UI.label("+150", 56, Color(1, 0.8, 0.25), 8, HORIZONTAL_ALIGNMENT_LEFT)
		cl.position = Vector2(250, 330)
		cl.size = Vector2(220, 70)
		p.add_child(cl)
		_btn(p, "AMBIL!", "btn_green", Vector2(70, 430), Vector2(420, 94), _claim_daily, 44)
	else:
		_dlabel(p, "Sudah diambil hari ini.\nKembali lagi besok!", 30, Vector2(20, 290), Vector2(520, 100))
		_btn(p, "TUTUP", "btn_blue", Vector2(70, 430), Vector2(420, 94), _close_popup, 44)


func _claim_daily() -> void:
	Game.claim_daily()
	Sound.sfx("coin")
	gift_badge.visible = false
	_close_popup()


func _settings() -> void:
	if not popup.is_empty():
		return
	popup = UI.make_popup(self, Vector2(560, 640), "PENGATURAN")
	var p: Panel = popup["panel"]
	_dlabel(p, "Musik", 36, Vector2(60, 86), Vector2(260, 100), Color(0.22, 0.13, 0.45), HORIZONTAL_ALIGNMENT_LEFT)
	var mb := UI.icon_button("ic_music_on" if Game.music_on else "ic_music_off", "btn_purple", Vector2(100, 100))
	mb.position = Vector2(400, 86)
	p.add_child(mb)
	mb.pressed.connect(func():
		_toggle_music()
		mb.get_child(0).texture = UI.tex("ic_music_on" if Game.music_on else "ic_music_off"))
	_dlabel(p, "Suara", 36, Vector2(60, 216), Vector2(260, 100), Color(0.22, 0.13, 0.45), HORIZONTAL_ALIGNMENT_LEFT)
	var sb := UI.icon_button("ic_sfx_on" if Game.sfx_on else "ic_sfx_off", "btn_purple", Vector2(100, 100))
	sb.position = Vector2(400, 216)
	p.add_child(sb)
	sb.pressed.connect(func():
		Sound.set_sfx(not Game.sfx_on)
		sb.get_child(0).texture = UI.tex("ic_sfx_on" if Game.sfx_on else "ic_sfx_off"))
	_btn(p, "RESET PROGRES", "btn_red", Vector2(70, 370), Vector2(420, 90), _confirm_reset, 34)
	_btn(p, "TUTUP", "btn_green", Vector2(70, 490), Vector2(420, 94), _close_popup, 44)


func _confirm_reset() -> void:
	_close_popup()
	popup = UI.make_popup(self, Vector2(560, 480), "RESET?")
	var p: Panel = popup["panel"]
	var l := _dlabel(p, "Semua level, bintang, dan koin akan dihapus. Yakin?", 30, Vector2(40, 90), Vector2(480, 160))
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	_btn(p, "YA, RESET", "btn_red", Vector2(70, 270), Vector2(420, 90), _do_reset, 38)
	_btn(p, "BATAL", "btn_blue", Vector2(70, 376), Vector2(420, 84), _close_popup, 38)


func _do_reset() -> void:
	Game.reset_progress()
	Game.go("menu")
